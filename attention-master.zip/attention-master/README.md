# attention

some attention implements

《Attention is All You Need》中的Attention机制的实现

http://kexue.fm/archives/4765/

## 测试环境

python 2.7 + tensorflow 1.8+ + keras 2.2.4

注：本项目不再跟进新版本的tensorflow/keras，如果有新版本的需求，可以到<a href="https://github.com/bojone/bert4keras/blob/master/bert4keras/layers.py">bert4keras的layers.py</a>处复制对应的函数。

## 交流
QQ交流群：67729435，微信群请加机器人微信号spaces_ac_cn
